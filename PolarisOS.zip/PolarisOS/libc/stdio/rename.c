#include <stdio.h>

/* TODO */

int rename(const char * oldpath, const char * newpath) {
    /* Unsupported */
    return -1;
}
