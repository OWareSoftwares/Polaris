int isgraph(int c) {
    return (c >= '!' && c <= '~');
}
