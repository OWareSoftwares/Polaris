#include <stdlib.h>
#include <locale.h>

char * setlocale(int category, const char *locale) {
    return "en_US";
}

