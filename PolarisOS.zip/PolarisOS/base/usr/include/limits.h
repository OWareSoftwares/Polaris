#pragma once

#define _LITTLE_ENDIAN

/* dummy */
