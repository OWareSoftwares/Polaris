#pragma once

#include <_cheader.h>

_Begin_C_Header
extern int sched_yield(void);
_End_C_Header
