#pragma once

#include <_cheader.h>

_Begin_C_Header
extern int mount(char * source, char * target, char * type, unsigned long flags, void * data);
_End_C_Header
