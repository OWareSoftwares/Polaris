#pragma once

#include <_cheader.h>
#include <stdlib.h>

_Begin_C_Header
extern int strcasecmp(const char *s1, const char *s2);
extern int strncasecmp(const char *s1, const char *s2, size_t n);
_End_C_Header

