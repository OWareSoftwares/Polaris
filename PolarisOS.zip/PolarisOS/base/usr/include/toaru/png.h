#pragma once

#include <_cheader.h>
#include <toaru/graphics.h>

_Begin_C_Header

extern int load_sprite_png(sprite_t * sprite, char * filename);

_End_C_Header

