#pragma once

#include <_cheader.h>
#include <toaru/graphics.h>

_Begin_C_Header

extern sprite_t * icon_get_16(const char * name);
extern sprite_t * icon_get_48(const char * name);

_End_C_Header

