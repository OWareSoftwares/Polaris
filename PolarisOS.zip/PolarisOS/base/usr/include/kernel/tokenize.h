#pragma once

int tokenize(char * str, const char * sep, char **buf);
