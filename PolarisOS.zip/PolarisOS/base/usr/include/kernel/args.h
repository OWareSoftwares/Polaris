#pragma once

int args_present(const char * karg);
char * args_value(const char * karg);
void args_parse(const char * arg);

