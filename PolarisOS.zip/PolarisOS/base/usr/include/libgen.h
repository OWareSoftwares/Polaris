#pragma once

#include <_cheader.h>

_Begin_C_Header

extern char * dirname(char * path);
extern char * basename(char * path);

_End_C_Header

