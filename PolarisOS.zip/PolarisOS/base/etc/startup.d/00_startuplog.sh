#!/bin/esh

# This daemonizes
exec splash-log
