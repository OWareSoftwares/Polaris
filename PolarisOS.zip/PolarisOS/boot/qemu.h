#pragma once
int detect_qemu(void);
