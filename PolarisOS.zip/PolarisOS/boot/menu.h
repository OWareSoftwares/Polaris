#pragma once

extern int boot_mode;
void show_menu(void);
