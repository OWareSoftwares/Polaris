#pragma once

extern int boot_edit;
int boot_editor(void);
