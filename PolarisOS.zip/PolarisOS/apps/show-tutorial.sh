#!/bin/sh

touch ~/.tutorial-shown
sh -c "sleep 1; tutorial" &

